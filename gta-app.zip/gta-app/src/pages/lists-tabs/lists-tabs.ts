import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';


import { BrowsePage } from '../browse/browse';
import { SearchPage } from '../search/search';
import { FavoritesPage } from '../favorites/favorites';

@IonicPage()
@Component({
  selector: 'page-lists-tabs',
  templateUrl: 'lists-tabs.html',
})
export class ListsTabsPage {

  tab1 = 'BrowsePage';
  tab2 = 'SearchPage';
  tab3 = 'FavoritesPage';


  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }


}
